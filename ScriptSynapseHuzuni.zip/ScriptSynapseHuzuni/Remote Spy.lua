--[[
	Remote Spy :D
]]
loadstring(game:HttpGet("https://raw.githubusercontent.com/BaconBABA/script/refs/heads/main/remotespy.lua"))()